package com.services.ServiceRegistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistryofAllServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
